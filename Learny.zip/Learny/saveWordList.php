<?php

    $name = 0;

    function saveWordList() {

        $servername = "192.168.2.11";
        $username = "root";
        $password = "SuperWebserver123";
        $dbname = "Learny";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $name = $_POST['name'];

        //Check if name already exist in db
        $sql = "SELECT * FROM wordList WHERE name='$name'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            //Name already exist
            echo    '<script type="text/javascript">' .
                    'POST = ["' . implode('", "', $_POST) . '"];' .
                    'replaceInput(POST);' .
                    '</script>';

        } else {

            //Insert Name
            $sql = "INSERT INTO wordList (name) VALUES ('$name')";

            if (mysqli_query($conn, $sql)) {
                $wordListID = mysqli_insert_id($conn);
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }

            //Insert Translations
            for ($i = 1; $i <= (sizeof($_GET) - 1) / 2; $i++) {

                $wordAID = strval($i) . 'A';
                $wordBID = strval($i) . 'B';

                $wordA = $_GET[$wordAID];
                $wordB = $_GET[$wordBID];

                $sql = "INSERT INTO translateItem (wordListID, WordA, WordB) VALUES ('$wordListID', '$wordA', '$wordB')";

                if ($conn->query($sql) === FALSE) {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                    break;
                }

            }

            $conn->close();

        }

    }

?>
