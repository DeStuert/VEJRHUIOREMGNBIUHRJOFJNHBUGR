<!DOCTYPE html>

<html>

    <link rel="stylesheet" type="text/css" href="css/style.css">

    <h1 style="color: blue">Test</h1>

    <?php
        include "saveWordList.php";
    ?>

    <form onsubmit="return false;" id="inputField" action="#" method="post">

        <div class="errorPopup" id='nameErrorPopup'></div>

        <p>Name: </p>
        <input type="text" name="name" id="name"></input>
        <br><br>
        <p>Translations: </p>

        <script>

            var name = "WordList";
            var translationAmount = 1;

            function addTranslation() {

                var inputField = document.getElementById('inputField');
                var newTranslationButton = document.getElementById('newTranslationButton');
                var inputElementA = document.createElement('input');
                var inputElementB = document.createElement('input');
                var br = document.createElement("br");

                inputElementA.setAttribute('type', 'text');
                inputElementA.setAttribute('name', translationAmount + 'A');
                inputElementB.setAttribute('type', 'text');
                inputElementB.setAttribute('name', translationAmount + 'B');

                inputField.insertBefore(inputElementA, newTranslationButton);
                inputField.insertBefore(inputElementB, newTranslationButton);
                inputField.insertBefore(br, newTranslationButton);

                translationAmount += 1;

            }

            addTranslation();

            function checkInput() {

                if (document.getElementById('name').value == '') {

                    errorElement = document.getElementById('nameErrorPopup');
                    errorElement.innerHTML = 'Please enter a name for your word list!';
                    errorElement.style.display = 'inline-block';

                } else {

                    document.getElementById('inputField').submit();

                }

            }

            function replaceInput(POST) {

                console.log(POST);

                //name = POST['name'];

                //nameInputElement = document.getElementById('name');

                //nameInputElement.value = name;

            }

        </script>

        <button type="button" onclick="addTranslation()" id="newTranslationButton">New Translation</button>

        <br><br>
        <button type="button" onclick="checkInput();">Save</button>

    </form>

    <?php

        if (isset($_POST['name'])) {

            saveWordList();

        }

    ?>

</html>
