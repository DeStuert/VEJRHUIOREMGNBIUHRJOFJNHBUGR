var wordIndex = 0;

var Words = [

    {term: "hallo", defenition: "hello"},
    {term: "welkom", defenition: "welcome"},
    {term: "hond", defenition: "dog"}

];
