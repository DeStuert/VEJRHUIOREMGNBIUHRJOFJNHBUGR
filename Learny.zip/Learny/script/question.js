function updateQuestion() {

    document.getElementById("word").innerHTML = Words[wordIndex].term;

};

updateQuestion();
