function submitAnswer() {

    var answer = document.getElementById("answer");

    if (answer.value == Words[wordIndex].defenition) {

        alert("Lekker bezig");

    }

    else {

        alert("Jammer joh");

    }

    wordIndex += 1;
    updateQuestion();
    answer.value = "";

}
